Proyecto para emular los sonidos de animales

![Screenshot](https://www.todopapas.com/img/cuentos/1/3/2/2/1322.jpg)