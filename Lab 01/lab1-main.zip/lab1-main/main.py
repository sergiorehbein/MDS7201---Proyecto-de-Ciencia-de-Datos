from animales import animales

if __name__ == '__main__':
    print("Ingrese el animalito para saber que dice:")
    animal = input()
    animales(animal)
